// 1 & 2 & 4
protocol PoliceMan {
    func arrestCriminals()
}

struct Person: PoliceMan {
    var name: String
    var toolMan: ToolMan
    func arrestCriminals() {
        self.name = name
    }
}

// 3
protocol ToolMan {
    func fixComputer()
}

// 5 & 6 Have no idea how to deal with the questions...

